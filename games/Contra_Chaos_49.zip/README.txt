Contra Chaos — four NEW editions (Player 49)

Play: https://garettwong.github.io/?v=49
Choose Contra S / F / L / SFL — Chaos. The old games remain available.
Intensity choices: More, Much more, A lot more, Crazily more.
Hold B or B lock to fire. Hold A or A lock for repeated mid-air jumps; release/unlock to fall. Tap A again for an immediate extra jump. Jumping is constrained near the top edge to avoid leaving the screen.

These are newly compiled NES ROMs with rapid fire, repeated jumping and broader F rotation. Use the matching web player for the expanded (up to 16,384) bullet field, true 64-path F corkscrews, intensity selection, added R targets and destructible hazards. A conventional emulator has the native ROM's 255 projectile slots and will not reproduce the expanded web-player field or its extra features. No claim of identical behaviour in Delta is made.

The new editions have separate saves. Existing editions and their saves are preserved. PC tests passed; physical iPhone performance remains unverified.
